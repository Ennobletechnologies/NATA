<html xmlns="http://www.w3.org/1999/xhtml">

    <head>

        <link href="favicon.ico" rel='icon' type='image/x-icon'/>

        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

        <title>Nata Members Report on <?php echo date('m/d/Y H:m')?></title>

        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>public/admin/style.css" />


    </head>

    <body>

        <div id="">



            <div class="header">

                <div class="title"><a href="<?php echo base_url() ?>admin/index"><img src="<?php echo base_url() ?>public/admin/images/logo.png"/></a></div>



                <div class="header_right">Welcome Admin, <a href="#" class="settings"></a> <a href="#" class="logout">Logout</a> <br><a class="backtoadmin" href="<?php echo base_url() ?>admin">Back to Admin</a></div>

            </div>   

            <div class="submenu">    

            </div>                         

            <div class="center_content">  

                <div id="right_wrap">

                    <div id="right_content">             

                        <ul id="tabsmenu" class="tabsmenu">

                            <li class="active"><a href="#tab1">Members Report</a></li>

                        </ul>

                        <div id="tab1" class="tabcontent">
                            <?php if (isset($_POST['submit'])) { ?>
                            
<a href="#" onClick="printdiv('div_print');" class="btn blue pull-right" style="padding: 5px;background-color: green;
    color: white;
    border-radius: 3px;
    font-size: 14px;
    float: right;
">Print Report</a>
                            <?php } ?>
                            <div class="form">


                                <div class="clear"></div>
                                
                                <?php if (isset($_POST['submit'])) { ?>
                                <div id="div_print">
                                    <h3>Report for the period of <?php echo $_POST['fromdate'] ."----".$_POST['todate'];?></h3> 
                                    <table style="width:720px;">
                                        <?php foreach ($myreport as $report) { ?>
                                            <tr>
                                                <td>Member Registration Date</td>
                                                <td>
                                                    <?php echo date ('m/d/Y', strtotime($report['dated'])); ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>First Name</td>
                                                <td>
                                                    <?php echo $report['member_name']; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Last Name</td>
                                                <td>
                                                    <?php echo $report['lastname']; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Spouse Name</td>
                                                <td>
                                                    <?php echo $report['name_of_spouse']; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Email</td>
                                                <td>
                                                    <?php echo $report['email']; ?>
                                                </td>
                                            </tr>
                                        <tr>
                                                <td>Home Phone</td>
                                                <td>
                                                    <?php echo $report['homephone']; ?>
                                                </td>
                                            </tr>
                                        <tr>
                                                <td>Children1 Name</td>
                                                <td>
                                                    <?php echo $report['children1']; ?>
                                                </td>
                                            </tr>
                                        <tr>
                                                <td>Children1 Age</td>
                                                <td>
                                                    <?php echo $report['age1']; ?>
                                                </td>
                                            </tr>
                                        <tr>
                                                <td>Children2 Name</td>
                                                <td>
                                                    <?php echo $report['children2']; ?>
                                                </td>
                                            </tr><tr>
                                                <td>Children2 Age</td>
                                                <td>
                                                    <?php echo $report['age2']; ?>
                                                </td>
                                            </tr>
                                        <tr>
                                                <td>Address1</td>
                                                <td>
                                                    <?php echo $report['aptno']; ?>
                                                </td>
                                            </tr>
                                        <tr>
                                                <td>Address2</td>
                                                <td>
                                                    <?php echo $report['address']; ?>
                                                </td>
                                            </tr>
                                        <tr>
                                                <td>City</td>
                                                <td>
                                                    <?php echo $report['city']; ?>
                                                </td>
                                            </tr>
                                        <tr>
                                                <td>State</td>
                                                <td>
                                                    <?php echo $report['state']; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Zip</td>
                                                <td>
                                                    <?php echo $report['zip']; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Cellphone</td>
                                                <td>
                                                    <?php echo $report['cellphone']; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Solicited_by:</td>
                                                <td>
                                                    <?php echo $report['solicited_by']; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Total Amount</td>
                                                <td>
                                                    <?php echo $report['total_amt']; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>..............................</td>
                                                <td>..............................</td>
                                            </tr>

                                        <?php } ?>                        
                                    </table>
                            </div>
                                    <?php //echo "<pre>";print_r($myreport);echo "</pre>";?>                          
                                <?php } ?>
                            </div>

                        </div>

                    </div>

                </div><!-- end of right content-->

                <div class="clear"></div>

            </div> <!--end of center_content-->

        </div>	

    </body>
<script language="javascript">
function printdiv(printpage)
{
var headstr = "<html><head><title></title></head><body>";
var footstr = "</body>";
var newstr = document.all.item(printpage).innerHTML;
var oldstr = document.body.innerHTML;
document.body.innerHTML = headstr+newstr+footstr;
window.print();
document.body.innerHTML = oldstr;
return false;
}
</script>
</html>                                                                                                                