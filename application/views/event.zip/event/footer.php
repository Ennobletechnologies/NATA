 <footer>
    <div class="row">
      <div class="col-lg-12">
        <p class="text-center">Happy Experience</p>
      </div>
    </div>
  </footer>
</div>

<!-- jQuery --> 
<script src="<?php echo base_url()?>assets/js/jquery.js"></script> 
<script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script> 
<script>
    $('.carousel').carousel({
        interval: 5000 //changes the speed
    })
    </script>
</body>
</html>
