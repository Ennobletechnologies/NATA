<header class="inner-carousel">
  <div class="inner-slider"> <img src="<?php echo base_url()?>assets/images/2.jpg" class="img-responsive">
    <div class="container">
      <div class="event-heading">
        <h2>Contact Information</h2>
        <h5>Happy to share you Information</h5>
      </div>
    </div>
  </div>
</header>
<div class="container-fluid mt40">
  <div class="col-lg-8">
    <div class="navigarion">
      <ol class="breadcrumb">
        <li><a href="index.html">Home</a></li>
        <li><a href="event-page.html">Events Page</a></li>
        <li><a href="#">Contact Information</a></li>
      </ol>
    </div>
    <div class="contact-details">
      <h4 class="contact-heading">Share your Contact Details</h4>
      <div class="row">
        <div class="col-md-10 col-xs-offset-1">
          <form role="form" action="<?php echo base_url()?>event/index/addUser" method="post">
            <hr class="colorgraph">
            <div class="row">
              <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                  <input type="text" name="fname" id="fname" class="form-control input-md" placeholder="First Name" tabindex="1" required/>
                </div>
              </div>
              <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                  <input type="text" name="lname" id="lname" class="form-control input-md" placeholder="Last Name" tabindex="2" required/>
                </div>
              </div>
            </div>
            <div class="form-group"> </div>
            <div class="row">
              <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                  <input type="email" name="email" id="email" class="form-control input-md" placeholder="Email Address" tabindex="4" required/>
                </div>
              </div>
              <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                  <input type="phoneNumber" name="phoneNumber" id="phoneNumber" class="form-control input-md" placeholder="Phone Number" tabindex="6" required/>
                </div>
              </div>
            </div>
			<input type="hidden" name="m_events_id" id="m_events_id" value="<?php echo $_POST['m_events_id'] ?>">
			<input type="hidden" name="m_event_date_id" id="m_event_date_id" value="<?php echo $_POST['m_event_date_id'] ?>">
			<input type="hidden" name="number_of_tickets" id="number_of_tickets" value="<?php echo $_POST['number_of_tickets'] ?>">
			<input type="hidden" name="m_events_cost" id="m_events_cost" value="<?php echo $_POST['m_events_cost'] ?>">
			<input type="hidden" name="m_events_name" id="m_events_name" value="<?php echo $_POST['m_events_name']; ?>">
			<input type="hidden" name="m_event_datetime" id="m_event_datetime" value="<?php echo $_POST['m_event_datetime']; ?>">
            <div class="row">
              <div class="col-xs-6 col-md-6 booking-btn">
                <input type="submit" value="Make a Payment" class="btn btn-md" tabindex="7">
				
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-4 col-sm-12">
    <div class="order-summary">
      <h5 class="text-uppercase">Order summary</h5>
      <h5><?php echo $_POST['m_events_name']; ?></h5>
      <table class="table table-striped">
        <tr>
          <td width="70%"><p>Regular :<?php echo $tickets = $_POST['number_of_tickets'] ?> ticket(s)
              This ticket grants entry to one and is inclusive of food and beverages.</p>
            <h5> <?php echo date("D, j M, Y g:i a", strtotime($_POST['m_event_datetime'])); ?> </h5></td>
          <td width="30%" style="background:#e2e2e2; text-align:center"><h2><?php echo $tickets; ?></h2>
            <p>Ticket(s)</p></td>
        </tr>
        <tr>
          <td>Sub Total</td>
          <td>$. <?php $total_cost= $_POST['m_events_cost']; echo ($total_cost*$tickets); ?></td>
        </tr>
        <tr>
          <td class="bold">Amount Payble</td>
          <td><h3>$. <?php echo ($total_cost*$tickets); ?></h3></td>
        </tr>
      </table>
    </div>
  </div>
</div>