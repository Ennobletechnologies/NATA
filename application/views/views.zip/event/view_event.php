
<header class="inner-carousel">
  <div class="inner-slider"> <img src="<?php echo base_url()?>assets/images/3.jpg" class="img-responsive">
    <div class="container">
      <div class="event-heading">
	  <?php foreach($events as $event) { ?>
        <h2><?php echo $event['m_events_name'];?></h2>
		        <h5>(Date comes)</h5>
	  <?php }?>
      </div>
    </div>
  </div>
</header>
<div class="container-fluid mt40">
  <div class="col-lg-8">
  <div class="navigarion">
      <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><a href="#">Events Page</a></li>
      </ol>
    </div>
    <p class="tickets-tab"><a href="#">Buy Tickets</a></p>
	<?php foreach($events as $event) { ?>
    <div class="mt20">
      <h4><?php echo $event['m_events_venue'];?></h4>
      <p></p>
    </div>
		<?php }?>
    <table border="0" class="table table-striped table-events">
      <thead>
        <tr>
          <th width="20%">Time</th>
          <th width="20%">No. of Tickets</th>
          <th width="20%">Entry Price</th>
          <th width="20%">Action</th>
        </tr>
      </thead>
      <tbody>
	  <?php foreach($eventtimings as $etime) { ?>
        <tr>
		<form action="<?php echo base_url()?>event/index/booktickets/<?php echo $etime['m_event_date_id'] ?>" method="post" id="">
          <td><?php echo date("D j M, g:i a", strtotime($etime['m_event_datetime'])); ?></td>
          <td><div class="input-group">
              <input id="number_of_tickets" type="text" value="1" name="number_of_tickets" >
            </div>
            <p class="hint">Child tickets will coming soon <!--Select your Tickets--></p></td>
          <td>$<?php echo $etime['m_events_cost'] ?></td>
		  <input type="hidden" name="m_event_date_id" id="m_event_date_id" value="<?php echo $etime['m_event_date_id'] ?>">
<input type="hidden" name="m_event_datetime" id="m_event_datetime" value="<?php echo $etime['m_event_datetime'] ?>">
<input type="hidden" name="m_events_cost" id="m_events_cost" value="<?php echo $etime['m_events_cost'] ?>">
<input type="hidden" name="m_events_id" id="m_events_id" value="<?php echo $etime['m_events_id'] ?>">
<input type="hidden" name="m_events_name" id="m_events_name" value="<?php echo $event['m_events_name'] ?>">
          <td class="booking-btn"><input type="submit" name="book" value="Book Tickets" id="submit" class="btn"></td>
		  </form>
        </tr>
       <?php }?>
      </tbody>
    </table>
    
  </div>
  <div class="col-lg-4">
  <?php foreach($events as $event) { ?>
    <h4>Event Description</h4>
    <p><?php echo $event['m_events_info'];?></p>
  <?php } ?>
      </div>
</div>
<script>
    $("input[name='number_of_tickets']").TouchSpin({
      verticalbuttons: true,
      verticalupclass: 'glyphicon glyphicon-plus',
      verticaldownclass: 'glyphicon glyphicon-minus'
    });
</script> 
<!--
<?php foreach($eventtimings as $etime) { ?>

<form action="<?php echo base_url()?>event/index/booktickets/<?php echo $etime['m_event_date_id'] ?>" method="post" id="">
<?php echo date("D j M, g:i a", strtotime($etime['m_event_datetime'])); ?>
, Cost:100,
<input type="text" name="number_of_tickets" value="1" id="number_of_tickets">
<input type="hidden" name="m_event_date_id" id="m_event_date_id" value="<?php echo $etime['m_event_date_id'] ?>">
<input type="hidden" name="m_event_datetime" id="m_event_datetime" value="<?php echo $etime['m_event_datetime'] ?>">
<input type="hidden" name="m_events_id" id="m_events_id" value="<?php echo $etime['m_events_id'] ?>">
<input type="submit" name="book" value="Book" id="submit" maxlength="4" size="4">
</form>
<?php }?>-->
