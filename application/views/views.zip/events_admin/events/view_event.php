<html>
<body>

 
<?php foreach($events as $event) { ?>
<?php echo $event['m_events_name']."<br>";?>
<?php echo $event['m_events_datetime']."<br>";?>
<?php }?>
</body>
</html>