<script type="text/javascript">
function imready(ids)
{
      	$.ajax({
                 type: 'POST',
                  context: 'application/json',
                    data: {id:ids,status:1},
                    url: 'http://nataus.org/events_admin/index/updatestatus',
                    success: function(msg) 
                    {
window.location.reload();
                    }
                });
}
function imnotready(ids)
{
	   	$.ajax({
                 type: 'POST',
                  context: 'application/json',
                    data: {id:ids,status:0},
                    url: 'http://nataus.org/events_admin/index/updatestatus',
                    success: function(msg) 
                    {

                     window.location.reload();
                    }
                });
}
</script>

			
<section>
 
  <div class="container">

			
				
      <div class="row" >
        <div class=" col-md-12" >
          <div class="panel panel-primary">
            <div class="panel-heading">
              <h4><i class="fa fa-list">&nbsp;</i>Booking History</h4>
            </div>
            <table class="table table-striped table-bordered" >
              <thead>
                <tr id="div1">
				
                  <th>Name</th>
                  <th><i class="fa fa-ticket">&nbsp;</i>Number Of Tickets</th>
				  <th>Ticket ID</th>
                  <th><i class="fa fa-dollar">&nbsp;</i>Price (Per ticket)</th>
                  <th><i class="fa fa-clock-o">&nbsp;</i>Event Date & Time</th>
                  <th><i class="fa fa-film">&nbsp;</i>Event</th>
				  <th><i class="fa fa-film">&nbsp;</i>Booked Time</th>
                  <!--<th><i class="fa fa-pencil">&nbsp;</i>Edit</th>
                  <th width="100"><i class="fa fa-trash">&nbsp;</i>Delete</th>-->
                  <th class="td-actions"><i class="fa fa-ticket">&nbsp;</i>Status</th>
                </tr>
              </thead>
              <tbody id="div2">
		<?php 
        foreach ($bookings as $bookingdata)
						  { 
						 ?>
                <tr >
                  <td><?php echo  $bookingdata['m_users_name']; ?></td>
                  <td><?php echo  $bookingdata['m_users_number_of_tickets']; ?></td>
				  <td><?php echo  "ET".$bookingdata['booking_id']; ?></td>
                  <td><?php echo  $bookingdata['ticket_cost']; ?></td>
                  <td><?php echo  date('M,d h:i a',strtotime($bookingdata['m_events_datetime'])); ?></td>
                  <td><?php echo  $bookingdata['m_events_name']; ?></td>
				  <td><?php echo  date('M,d h:i a',strtotime($bookingdata['m_users_register_date'])); ?></td>
                  <!--<td class="td-actions"><a href="editbooking.html" class="btn btn-small btn-success"><i class="fa  fa-pencil"> </i></a></td>
                  <td><a href="javascript:;" class="btn btn-danger btn-small"><i class="fa fa-remove"> </i></a></td>-->
                  <td class="text-center">
				  <?php $sts= $bookingdata['booking_status']; if($sts==1){?>
				  Active <input type="checkbox" name="status[]" checked="checked" id="status<?php echo  $bookingdata['m_bookings_id']; ?>" onclick="imnotready(<?php echo  $bookingdata['m_bookings_id']; ?>)"/>
				  <?php } else {?>
				  Blocked <input type="checkbox" name="status[]" id="status<?php echo  $bookingdata['m_bookings_id']; ?>" onclick="imready(<?php echo  $bookingdata['m_bookings_id']; ?>)"/>
				  <?php } ?>
				  </td>
                </tr>
				<?php } 	?>
				
			  </tbody>
            </table>
			<?php //echo "<pre>";print_r($bookings);echo "</pre>"; ?>
          </div>
        </div>
      </div>

    </div>

</section>

